/**
 * 
 */
/**
 * 
 */
module GrisesiaRpg_Combat {
	requires spigot;
	requires Multiverse.Portals;
	requires Multiverse.Core;
	requires WorldGuardEvents;
	requires worldguard.bukkit;
	requires worldedit.bukkit;
}